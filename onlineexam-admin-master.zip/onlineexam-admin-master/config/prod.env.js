'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://maweitao.top/oes/api"',
  BASE_WEBSOCKET: '"ws://maweitao.top:8080/oes/api/websocket/"'
}
