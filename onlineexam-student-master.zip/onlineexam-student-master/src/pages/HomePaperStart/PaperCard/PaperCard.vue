<template>
  <section class="paper_card">
    答题卡
  </section>
</template>

<script>
  export default {
    name: "",
    data() {
      return {}
    },
    methods: {}
  }
</script>

<style lang="stylus" type="text/stylus" rel="stylesheet/stylus" scoped>

</style>
